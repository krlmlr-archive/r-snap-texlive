%% mpicpm07-14.m  (Figure 7.14)
%% curved arrow
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
\beginpicture
paper{units(1cm) xrange(0,5)  yrange(0,4), axis(LRTB),ticks(1,1)}
point(P){1.25,1}
point(Q){P, polar(2, 65 deg)}
point(R){Q, polar(2,-40 deg)}
drawpoint(Q)
text(\fbox{START}){P}[t]
text($Q$){Q, shift(0,0.5)}
text(\raisebox{-5mm}{\fbox{END}}){R}[t]
linethickness(1pt)
arrowshape(0.4cm, 30,40)
system("perl drawcurvedarrow.pl P Q R 0.4 temp.txt")
inputfile(temp.txt)
\endpicture
\end{document}
