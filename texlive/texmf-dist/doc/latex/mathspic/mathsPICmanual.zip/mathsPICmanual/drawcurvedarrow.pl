#!/usr/bin/perl
## drawcurvedarrow.pl
# command-line parameters A B C h filename
my ($A, $B, $C, $h, $filename)=@ARGV;
open (outfile, ">$filename")|| die "ERROR can't create file $filename\n";
print (outfile  "Point*(P999){pointonline($B$A, -($A$B)/3)}\n");
print (outfile  "Point*(H999){pointonline($C P999,$h)}\n");
print (outfile  "Drawcurve($A$B H999)\n");
print (outfile  "drawArrow(H999 $C)\n");
close (outfile);
