%% mpicDemo.m
%% modified from my  fig2tetra-bw6.m 
%% for the mathsPIC manual
%% May 28, 2011
%%-------------


\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%--------------
\beginpicture
\setsolid
%% compress Y scale to fit equation onto paper
var u=1, v=0.075 
paper{units(u cm, v cm), xrange(-4,5), yrange(-50,10),  axes(XY), ticks(1,0)}
%% place values at ends of the Y-axisuse make only some of the ticks
\axis left shiftedto x=0 
    \   ticks withvalues $-50$  $10$   /
    \                  at -50   10     /  /
\endpicture
\end{document}
