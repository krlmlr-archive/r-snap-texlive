%% mpicpm03-3.m (Figure 3.3)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%-------------
\framebox{\vbox{
\beginpicture
paper{units(1mm),xrange(0,28),yrange(0,10)}
point(P){25,5}[symbol=$\bullet$,radius=2]
text(\fbox{a nice box}){P}[r]
drawpoint(P)
point(J){P,polar(15,-20deg)}[radius=2]
text(this is point P){J}[l]
drawarrow(JP)
\endpicture
\  }}  %% end of framebox
%%----------
\end{document}