%% READMEmathspic.txt
%% RWD Nickalls
%% dick@nickalls.org
---------------------

the main file for the manual is <mathsPICmanual.tex>.
This file inputs all the separate chapter files (all within the same directory).
