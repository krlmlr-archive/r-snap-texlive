%% mpicpm03-2.m (Figure 2 - chapter 3)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%-----------
\beginpicture
paper{units(1cm),xrange(0,6),yrange(0,3),axes(LBT*R*),ticks(1,1)}
point(P){4,2}[symbol=$\odot$]
point(B){2,0.5}
point(S){1,2}
drawPoint(PBS)
\setdashes
\inboundscheckon        %% restrict circles to drawing area
drawcircle(P,1)
drawcircle(P,2)
\setsolid
%% change line-free radius of P to 1cm
point*(P){P}[radius=1]
drawArrow(BP)           %% draw arrow from B (below)
%% change line-free radius of P to 2cm
point*(P){P}[radius=2]
drawArrow(SP)           %% draw arrow from S (side)
text($S$){S, shift(-0.4,0)}
text($B$){B, shift(-0.4,0)}
text(\textsc{p}){P, shift(0.3,0)}
\newcommand{\textbox}{\fbox{text\hspace{17mm}box}}%
text(\textbox){P}
\endpicture
%%--------
\end{document}
