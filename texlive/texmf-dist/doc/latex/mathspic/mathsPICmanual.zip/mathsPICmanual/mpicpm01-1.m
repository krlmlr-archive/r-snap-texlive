%% mpicpm01-1.m  (figure 1 - chapter 1)
%% mathsPIC  (smallTriangle with incircle)
%%-------------------
\documentclass[a4paper]{article}
\usepackage{mathspic,color}
\begin{document}
%%---------------------
\beginpicture
\setdashes
\color{blue}%
paper{units(1cm) xrange(-0.5,5), yrange(-0.5,2.5) axes(XY)}
\setsolid
point(A){0,0}
point(B){A, polar(5, 10 deg)}
point(C){A, polar(3, 50 deg)}
\color{black}%
drawpoint(ABC)
drawLine(ABCA)
\color{red}%
drawIncircle(ABC)
\color{black}%
var d = 0.5
text($A$){A, polar(d,-140 deg)}
text($B$){B, shift(d,0)}
text($C$){C, shift(-d,0)}
\endpicture
%%-----------------
\end{document}
