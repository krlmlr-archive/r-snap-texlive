%% mpicpm07-1.m  (figure 7.1)
%% mathsPIC  Perl  triangle
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%-------------------
\beginpicture
\setdashes
paper{units(1mm),xrange(0,70),yrange(0,50),axes(LRTB),ticks(10,10)}
\setsolid
point(A){10,10}[symbol=$\odot$, radius=1.2]     %% anchor point
point(B){A, polar(40, 50 deg)}[symbol=$\odot$, radius=1.2]
point(C){A, polar(50, 10 deg)}[symbol=$\odot$, radius=1.2]
point(D){perpendicular(B,AC)}
drawPoint(ABCD)
drawLine(ABCA)
\setdashes
drawLine(BD)
\setsolid
drawRightangle(BDC,2.5)
text($B$){B, shift(-1,4)}
text($A$){A, shift(-4,-2)}
text($C$){C, shift(4,-1)}
text($D$){D, shift(1,-4)}
showLength(BD)
showLength(AC)
showArea(ABC)
showAngle(ABC)
\endpicture
%%------------------
\end{document}
