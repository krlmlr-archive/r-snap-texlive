%% mpicpm07-10.m  (figure 7-10)
%% mathsPIC  small spiral by recursion
%%  (requires datafile mpicpm07-10.dat)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%---------------
\beginpicture
paper{units(1mm), xrange(0,60), yrange(0,60)}% axes(LB), ticks(10,10)}
point(C){30,30}   % circle center
drawcircle(C,25)
%% initialise the reusable points and variables
var a=315  % angle degrees
var r=20   % start radius
var s=5    % square semi-diagonal
point(T){C,polar(r,330 deg)}
%% cycle datafile 35 times
inputfile(mpicpm07-10.dat)[35]
\endpicture
%%----------------
\end{document}
