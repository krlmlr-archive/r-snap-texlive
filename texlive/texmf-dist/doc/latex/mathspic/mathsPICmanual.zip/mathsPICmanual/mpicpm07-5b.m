%% mpicpm07-5b.m (figure 7.5b)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%-------------------
\beginpicture
paper{units(1mm),xrange(0,45),yrange(0,45)}%, axes(LB), ticks(10,10)}
point(P){5,10}[symbol=$P$,radius=5]
point(Q){P,polar(30,90 deg)}[symbol=$Q$,radius=5]
point(R){Q,polar(40,0 deg)}[symbol=$R$,radius=5]
point(T){P,polar(30,0 deg)}[symbol=$T$,radius=5]
drawPoint(PQRT)
drawArrow(PQ,QR,PT,TR,PR)
point(P1){midpoint(PQ)}
text($p_1$){P1,shift(3,0)}
point(P2){midpoint(PT)}
text($p_2$){P2,shift(0,-3)}
point(P3){midpoint(PR)}
text($p_3$){P3,shift(2,-2)}
point(T1){midpoint(TR)}
text($t$){T1,shift(3,0)}
point(Q1){midpoint(QR)}
%% use a macro for the label
\newcommand{\q}{$q \star q \star q \star q \star q$}
text(\q){Q1,shift(-1,3)}
\endpicture
%%------------------
\end{document}
