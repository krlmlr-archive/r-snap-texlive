%% mpicpm07-4.m (Figure 7-4)
%% mathsPIC   arrow in triangle
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%-------------------
\beginpicture
paper{units(1mm),xrange(5,45),yrange(5,45)}
point(A){30,30}
point(P){10,10}
point(B){30,10}
drawPoint(APB)
drawLine(APBA)
var d = 5
text($A$){A,shift(1,d)}
text($B$){B,shift(d,0)}
text($P$){P,shift(-d,0)}
drawAngleArrow{angle(BPA),radius(11),internal, anticlockwise}
text($\psi$){P,polar(7,22.5 deg)}
drawRightangle(ABP,2.5)
\endpicture
%%------------------
\end{document}
