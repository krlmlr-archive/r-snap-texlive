%% mpicpm03-1a.m  (figure 1a - chapter 3)
%% mathsPIC    axes
%%-------------
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%---------------
\beginpicture
%% setup the plot area
paper{units(1mm),xrange(0,50),yrange(0,50),axes(LRTB),ticks(10,10)}
\endpicture
%%-------------------
\end{document}
