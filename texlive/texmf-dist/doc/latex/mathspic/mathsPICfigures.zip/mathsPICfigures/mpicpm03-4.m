%% mpicpm03-4.m (Figure 3.4)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%--------------------
\beginpicture
paper{units(1mm), xrange(0,60), yrange(0,60) axes(LB), ticks(10,10)}
point(S){7,55}   % Start position
drawpoint(S)
%% initialise parameters
var n=0     % initialise mathspic counter
var a=-180  % start angle degrees
var d=50    % start length
beginloop 40
% ===========
var n=n+1, a = a+90, d = d-1 %% increment loop counter, angle and length
point*(P){S,polar(d,a deg)} % generate new point P
drawline(SP) % draw line from OLD S to NEW P
point*(S){P} %% reallocate S <-- P
% ===========
endloop
drawpoint(P)
\endpicture
%%----------
\end{document}


