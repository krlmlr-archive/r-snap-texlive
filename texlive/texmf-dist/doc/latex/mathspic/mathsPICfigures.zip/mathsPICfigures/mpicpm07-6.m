%% mpicpm07-6.m  (figure 7.6)
%% mathsPIC   (4 circles figure)
\documentclass[a4paper]{article}
\usepackage{mathspic,color}
\begin{document}
%%-------------------
\beginpicture
paper{units(1mm),xrange(0,70),yrange(0,60)}%
point(A){30,11}[symbol=circle(8),radius=8]
point(B){A,shift(-10,30)}[symbol=circle(15),radius=15]
point(C){A,polar(30,20 deg)}[symbol=circle(5),radius=5]
point(D){A,polar(45,50 deg)}[symbol=circle(7),radius=7]
\color{red}%
drawPoint(ABCD)
\color{blue}%
drawLine(AB,AC,BC,BD,CD)
\setdashes
drawLine(AD)
\color{black}%
text($A$){A}
%% use a macro for the formula
\newcommand{\formula}{%
\     $\displaystyle \sum_{p\ge0} \Delta_{jp} z^{(p+1)}$%
\     }%
text(\formula){B}
text($C$){C}
text($D$){D}
\endpicture
%%------------------
\end{document}
