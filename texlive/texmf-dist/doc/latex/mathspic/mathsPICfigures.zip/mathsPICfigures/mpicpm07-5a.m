%% mpicpm07-5a.m (figure 5a)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%\framebox{\vbox{
%%-------------------
\beginpicture
paper{units(1mm),xrange(10,40),yrange(0,45)}%, axes(LB), ticks(10,10)}
point(N){15,20}
point(S){N,shift(20,0)}
text(\framebox{$N$}){N,shift(0,-2.5)}
text(\framebox{$S$}){S,shift(0,-2.5)}
point(Z){midpoint(NS)}
drawAngleArrow{angle(NZS),radius(NZ),internal,clockwise}
point(N1){N,shift(2,1)}
point(S1){S,shift(-2,1)}
point(Z1){Z,shift(0,-3)}
drawAngleArrow{angle(N1Z1S1),radius(N1Z1),internal,clockwise}
point(N2){N1,shift(2,-0.5)}
point(S2){S1,shift(-2,-0.5)}
point(Z2){Z,shift(0,-10)}
drawAngleArrow{angle(N2Z2S2),radius(N2Z2),internal,clockwise}
\endpicture
%\  }}
\end{document}
