%% mpicpm07-15.m  (Figure 7.15)
\documentclass[a4paper]{article}
\usepackage{mathspic,color}
\begin{document}
%%-----------
\beginpicture
paper{units(1cm) xrange(0,6)  yrange(0,6), axis(LB),ticks(1,1)}
point(P){3,3}[symbol=$\bigodot$]  %center of the cube
%def center(j)j%     %% center point
%def filename(j)j%   %% temp filename
%def side(j)j%       %% sidelength
var s=3  %% sidelength
system("perl drawcube.pl &center(P) &side(s) &filename(temp.txt)")
inputfile(temp.txt)
\endpicture
%%---------
\end{document}
