%% mpicpm07-12.m  (Figure 7.12)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\usepackage{amssymb}
\begin{document}
\beginpicture
%----------------
paper{units(1cm),xrange(0,6),yrange(73,77),axes(LBT*R*),ticks(1,1)}
pointsymbol($\odot$,0.2)
point(d1){1, 76.2}
point(d2){2, 76.2}
point(d3){3, 75.5}
point(d4){4, 75.7}
point(d5){5, 74.6}
drawpoint(d1d2d3d4d5)
drawline(d1d2d3d4d5)
%
pointsymbol($\boxdot$, 0.2)
point(k1){1, 75.2}
point(k2){2, 75.4}
point(k3){3, 74.8}
point(k4){4, 74.1}
point(k5){5, 74.0}
drawpoint(k1k2k3k4k5)
\setdashpattern <2pt, 2pt>
drawline(k1k2k3k4k5)
%
\plotheading{\textsf{\Large Weight change with diet}}
text(\shortstack{\textsf{\large Weight}\\($kg$)}){-1.5,75.3}
text(\textsf{\large Weeks}){3,72}
\endpicture
\end{document}
