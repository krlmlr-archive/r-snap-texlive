%% mpicpm03-1b.m  (figure 1b - chapter 3)
%% mathsPIC   axes
%%-------------
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%---------------
\beginpicture
%% setup the plot area
paper{units(1cm),xrange(-2,3),yrange(-2,3),axes(XY),ticks(1,1)}
\endpicture
%%-------------------
\end{document}
