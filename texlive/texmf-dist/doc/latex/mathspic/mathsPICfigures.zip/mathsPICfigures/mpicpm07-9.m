%% mpicpm07-9.m (figure 7.9)
%% mathsPIC  dynamic figure
%%-------------------
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%---------------------
\beginpicture
paper{units(1mm), xrange(5,110), yrange(0,45)}
point(A){15,5}[symbol=$\odot$, radius=1.2]
point(P){A, shift(10,30)}[symbol=$\odot$, radius=1.2]
point(B){A, polar(45,60 deg)}
point(Q){perpendicular(P,AB)}
drawRightangle(PQA,2)
drawPoint(ABPQ)
drawLine(ABPQ)
drawIncircle(PQB)
var d = 5
text($A$){A,shift(-d, 0)}
text($B$){B,shift(d, 0)}
text($P$){P,shift(-d, 0)}
point(S){pointOnLine(QP,-5)}
text($Q$){S}
point(N){A,shift(0,10)}
\setdashes
drawline(AN)
\setsolid
drawAngleArrow{angle(NAB), radius(5.7), internal, clockwise}
%%---------  second figure
point*(A){60,5}[symbol=$\odot$, radius=1.2]
point*(P){A, shift(10,30)}[symbol=$\odot$, radius=1.2]
point*(B){A, polar(45,5 deg)} %%5 60 deg
point*(Q){perpendicular(P,AB)}
drawRightangle(PQA,2)
drawPoint(ABPQ)
drawLine(ABPQ)
drawIncircle(PQB)
text($A$){A,shift(-5, 0)}
text($B$){B,shift(5, 0)}
text($P$){P,shift(-5, 0)}
point*(S){pointOnLine(QP,-5)}
text($Q$){S}
point*(N){A,shift(0,10)}
\setdashes
drawline(AN)
\setsolid
drawAngleArrow{angle(NAB), radius(5.7), internal, clockwise}
%%------
\endpicture
\end{document}
