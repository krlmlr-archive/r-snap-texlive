
README.txt
mathsPIC v 1.13
---------------
These  are all the .m files used  in the  mathsPIC manual.
They  are for users to experiment with, as they wish.


(1) drawcurvedarrow.pl is used by program mpicpm07-14 in Example 1 (Chapter Examples; -- see section on "Using Perl programs") in the mathsPIC manual.

(2) drawcube.pl is used used by program mpicpm07-15 in Example 2 (Chapter Examples; -- see section on "Using Perl programs") in the mathsPIC manual.


RWD Nickalls
dick@nickalls.org 