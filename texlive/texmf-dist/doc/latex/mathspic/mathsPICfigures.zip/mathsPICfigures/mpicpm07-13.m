%% mpicpm07-13.m  (Figure 7.13)
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
\beginpicture
var u = 12    %%  units = 12 mm
paper{units(Umm),xRange(0.5,8.5),yRange(-0.5,5.5)}
var r = 0.7  %% line-free radius of \circ (0.7mm)
var r = r/u  %% line free radius scaled for U mm
pointsymbol($\circ$,r)
Point(A){1,1}
Point(B){2,4}
Point(C){5,3}
Point(D){6,0}
Point(E){8,2}
Point(F){8,5}
Point(G){3,0}
pointsymbol(default)  %% restore $\bullet$
%
Point(A1){midpoint(AB)}
Point(B1){midpoint(BC)}
Point(C1){midpoint(CD)}
Point(D1){midpoint(DE)}
Point(E1){midpoint(EF)}
Point(F1){midpoint(FG)}
Point(G1){midpoint(GA)}
%
Point(A2){midpoint(G1A1)}
Point*(A2){midpoint(AA2)}
Point(B2){midpoint(A1B1)}
Point*(B2){midpoint(BB2)}
Point(C2){midpoint(B1C1)}
Point*(C2){midpoint(CC2)}
Point(D2){midpoint(C1D1)}
Point*(D2){midpoint(DD2)}
Point(E2){midpoint(D1E1)}
Point*(E2){midpoint(EE2)}
Point(F2){midpoint(E1F1)}
Point*(F2){midpoint(FF2)}
Point(G2){midpoint(F1G1)}
Point*(G2){midpoint(GG2)}
%
DrawPoint(ABCDEFG)
DrawPoint(A1B1C1D1E1F1G1)
DrawPoint(A2B2C2D2E2F2G2)
%
DrawLine(ABCDEFGA)
\setplotsymbol ({\Large.})
DrawCurve(A1B2B1)
DrawCurve(B1C2C1)
DrawCurve(C1D2D1)
DrawCurve(D1E2E1)
DrawCurve(E1F2F1)
DrawCurve(F1G2G1)
DrawCurve(G1A2A1)
%
Text($A$){A,shift(-0.2,0)}
Text($B$){B,shift(-0.2,0.1)}
Text($C$){C,shift(0,0.25)}
Text($D$){D,shift(0,-0.25)}
Text($E$){E,shift(0.2,0)}
Text($F$){F,shift(0,0.25)}
Text($G$){G,shift(0,-0.25)}
\scriptsize
Text($A_1$){A1,shift(0.25,0)}
Text($B_1$){B1,shift(0,-0.2)}
Text($C_1$){C1,shift(0.25,0)}
Text($D_1$){D1,shift(-0.2,0.15)} %
Text($E_1$){E1,shift(-0.2,0)}
Text($F_1$){F1,shift(0.15,-0.15)}
Text($G_1$){G1,shift(0.1,0.2)}
Text($A_2$){A2,shift(0.25,0)}
Text($B_2$){B2,shift(0.1,-0.2)}
Text($C_2$){C2,shift(-0.1,-0.15)}
Text($D_2$){D2,shift(0.1,0.2)}
Text($E_2$){E2,shift(-0.25,0.05)} %
Text($F_2$){F2,shift(0.05,-0.2)}  %
Text($G_2$){G2,shift(0,0.25)}    %
\endpicture
\end{document}
