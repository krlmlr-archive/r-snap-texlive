%% mpicpm07-2.m (figure 7.2)
%% mathsPIC  rectangular box
\documentclass[a4paper]{article}
\usepackage{mathspic}
\begin{document}
%%----------------------
\beginpicture
paper{units(1mm), xrange(0,50), yrange(0,62)}
var s= 20  % Sides front & back
var L = 34  % Length
var a2 = 56.6  % angle degrees
%def fancydashes()dasharray(6pt,2pt, 1pt, 2pt)%
%def simpledashes()dasharray(4pt,4pt)%
point(A){5,7}
point(B){A, polar(s,90 deg)}
point(C){B, polar(s,0  deg)}
point(D){A, polar(s,0  deg)}
point(H){A, polar(L,a2 deg)}
point(G){B, polar(L,a2 deg)}
point(F){C, polar(L,a2 deg)}
point(E){D, polar(L,a2 deg)}
drawpoint(ABCDEFGH)
linethickness(2pt)
  \setsolid
drawline(ABCDA)
  \setdashes
drawline(HGFEH)
linethickness(default)
&fancydashes
drawline(AH, DE)
&simpledashes
drawline(BG, CF)
text($A$){A, shift(-2,-4)}
text($B$){B, shift(-4,1)}
text($C$){C, shift(4,0)}
text($D$){D, shift(1,-4)}
text($E$){E, shift(4,0)}
text($F$){F, shift(2,4)}
text($G$){G, shift(-1,4)}
text($H$){H, shift(-4,1)}
\endpicture
%%-------------------
\end{document}
